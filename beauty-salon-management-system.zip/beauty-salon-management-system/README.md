# Beauty Salon Management System
React + Vite frontend, Java 21 / Spring Boot backend, MySQL 8 database.

## Run
1. Install Java 21, Node.js 20+, Maven, and MySQL 8.
2. In MySQL Workbench run `database/schema.sql`, then `database/seed.sql`.
3. Edit `backend/src/main/resources/application.properties` and set your MySQL password.
4. In a terminal: `cd backend` then `mvn spring-boot:run`.
5. In another terminal: `cd frontend` then `npm install` and `npm run dev`.
6. Open http://localhost:5173.

## Demo logins
Customer: `customer1` / `customer123`
Staff: `staff1` / `staff123`
Admin: `admin` / `admin123`
Staff accounts staff2-staff55 use password `staff123`.

## Included
- Three separate role login portals
- 55 parlours with salon image URLs
- Six services and an assigned staff account per parlour
- Service selection, staff selection, date/time booking
- Backend overlap check based on appointment start/end
- Customer booking history, staff schedule, admin staff/service creation
- Responsive design with 120 colour palette tokens

This is an academic starter project, not production-ready. Before real deployment, replace plaintext demo passwords with BCrypt, add Spring Security/JWT, implement full admin CRUD and authorization, and add database locking/transaction strategy for simultaneous booking requests.
