package com.beautysalon;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.*;
import java.time.*;
import java.sql.Timestamp;
@RestController @RequestMapping("/api") @CrossOrigin(origins="http://localhost:5173")
public class ApiController {
 private final JdbcTemplate db; public ApiController(JdbcTemplate db){this.db=db;}
 @GetMapping("/health") public Map<String,String> health(){return Map.of("status","ok");}
 @PostMapping("/login") public ResponseEntity<?> login(@RequestBody Map<String,String>b){
  var rows=db.queryForList("SELECT id,username,role,display_name,email FROM app_users WHERE username=? AND password=? AND active=TRUE",b.getOrDefault("username",""),b.getOrDefault("password",""));
  return rows.isEmpty()?ResponseEntity.status(401).body(Map.of("message","Invalid username or password")):ResponseEntity.ok(rows.get(0));
 }
 @GetMapping("/parlours") public List<Map<String,Object>> parlours(@RequestParam(required=false)String search){
  if(search==null||search.isBlank())return db.queryForList("SELECT * FROM parlours WHERE active=TRUE ORDER BY id");
  String q="%"+search+"%";return db.queryForList("SELECT * FROM parlours WHERE active=TRUE AND (name LIKE ? OR city LIKE ? OR area LIKE ?) ORDER BY id",q,q,q);
 }
 @GetMapping("/parlours/{id}/services") public List<Map<String,Object>> services(@PathVariable long id){return db.queryForList("SELECT * FROM services WHERE parlour_id=? AND active=TRUE",id);}
 @GetMapping("/parlours/{id}/staff") public List<Map<String,Object>> staff(@PathVariable long id){return db.queryForList("SELECT s.id,s.parlour_id,s.specialization,u.display_name FROM staff s JOIN app_users u ON u.id=s.user_id WHERE s.parlour_id=? AND s.active=TRUE",id);}
 @GetMapping("/appointments") public List<Map<String,Object>> appointments(@RequestParam long userId,@RequestParam String role){
  String base="SELECT a.*,p.name parlour_name,se.name service_name,cu.display_name customer_name,su.display_name staff_name FROM appointments a JOIN parlours p ON p.id=a.parlour_id JOIN services se ON se.id=a.service_id JOIN app_users cu ON cu.id=a.customer_user_id JOIN staff s ON s.id=a.staff_id JOIN app_users su ON su.id=s.user_id ";
  if("ADMIN".equals(role))return db.queryForList(base+"ORDER BY a.appointment_start DESC");
  if("STAFF".equals(role))return db.queryForList(base+"WHERE s.user_id=? ORDER BY a.appointment_start",userId);
  return db.queryForList(base+"WHERE a.customer_user_id=? ORDER BY a.appointment_start DESC",userId);
 }
 @PostMapping("/appointments") public ResponseEntity<?> book(@RequestBody Map<String,Object>b){
  try{
   long customer=Long.parseLong(b.get("customerUserId").toString()),parlour=Long.parseLong(b.get("parlourId").toString()),service=Long.parseLong(b.get("serviceId").toString()),staff=Long.parseLong(b.get("staffId").toString());
   LocalDateTime start=LocalDateTime.parse(b.get("start").toString());
   Map<String,Object> sv=db.queryForMap("SELECT duration_minutes,parlour_id FROM services WHERE id=? AND active=TRUE",service);
   Map<String,Object> st=db.queryForMap("SELECT parlour_id,working_start,working_end FROM staff WHERE id=? AND active=TRUE",staff);
   if(((Number)sv.get("parlour_id")).longValue()!=parlour||((Number)st.get("parlour_id")).longValue()!=parlour)return ResponseEntity.badRequest().body(Map.of("message","Service and staff must belong to the selected parlour."));
   LocalDateTime end=start.plusMinutes(((Number)sv.get("duration_minutes")).intValue());
   LocalTime ws=((java.sql.Time)st.get("working_start")).toLocalTime(),we=((java.sql.Time)st.get("working_end")).toLocalTime();
   if(start.toLocalTime().isBefore(ws)||end.toLocalTime().isAfter(we)||!start.toLocalDate().equals(end.toLocalDate()))return ResponseEntity.badRequest().body(Map.of("message","Appointment is outside staff working hours."));
   Integer conflicts=db.queryForObject("SELECT COUNT(*) FROM appointments WHERE staff_id=? AND status IN ('BOOKED','CONFIRMED') AND appointment_start < ? AND appointment_end > ?",Integer.class,staff,Timestamp.valueOf(end),Timestamp.valueOf(start));
   if(conflicts!=null&&conflicts>0)return ResponseEntity.status(409).body(Map.of("message","Staff member is already booked during that time. Choose another slot."));
   db.update("INSERT INTO appointments(customer_user_id,parlour_id,service_id,staff_id,appointment_start,appointment_end,status) VALUES(?,?,?,?,?,?,'BOOKED')",customer,parlour,service,staff,Timestamp.valueOf(start),Timestamp.valueOf(end));
   return ResponseEntity.ok(Map.of("message","Appointment booked successfully"));
  }catch(Exception e){return ResponseEntity.badRequest().body(Map.of("message",e.getMessage()==null?"Booking failed":e.getMessage()));}
 }
 @PatchMapping("/appointments/{id}/status") public ResponseEntity<?> status(@PathVariable long id,@RequestBody Map<String,String>b){
  String s=b.getOrDefault("status","");if(!Set.of("BOOKED","CONFIRMED","COMPLETED","CANCELLED").contains(s))return ResponseEntity.badRequest().body(Map.of("message","Invalid status"));
  int n=db.update("UPDATE appointments SET status=? WHERE id=?",s,id);return n==0?ResponseEntity.notFound().build():ResponseEntity.ok(Map.of("message","Status updated"));
 }
 @GetMapping("/admin/staff") public List<Map<String,Object>> allStaff(){return db.queryForList("SELECT s.id,s.parlour_id,s.specialization,u.username,u.display_name,p.name parlour_name FROM staff s JOIN app_users u ON u.id=s.user_id JOIN parlours p ON p.id=s.parlour_id ORDER BY s.id");}
 @GetMapping("/admin/services") public List<Map<String,Object>> allServices(){return db.queryForList("SELECT se.*,p.name parlour_name FROM services se JOIN parlours p ON p.id=se.parlour_id ORDER BY p.name,se.name");}
 @PostMapping("/admin/staff") public ResponseEntity<?> createStaff(@RequestBody Map<String,String>b){
  try{db.update("INSERT INTO app_users(username,password,role,display_name,email) VALUES(?,?,'STAFF',?,?)",b.get("username"),b.get("password"),b.get("displayName"),b.get("email"));
   Long uid=db.queryForObject("SELECT id FROM app_users WHERE username=?",Long.class,b.get("username"));
   db.update("INSERT INTO staff(user_id,parlour_id,specialization,working_start,working_end) VALUES(?,?,?,'09:00','19:00')",uid,Long.parseLong(b.get("parlourId")),b.getOrDefault("specialization","Beauty Specialist"));
   return ResponseEntity.ok(Map.of("message","Staff account created"));
  }catch(Exception e){return ResponseEntity.badRequest().body(Map.of("message","Could not create staff account. Check that the username is unique."));}
 }
 @PostMapping("/admin/services") public ResponseEntity<?> createService(@RequestBody Map<String,Object>b){
  db.update("INSERT INTO services(parlour_id,name,description,price,duration_minutes) VALUES(?,?,?,?,?)",b.get("parlourId"),b.get("name"),b.getOrDefault("description",""),b.get("price"),b.get("durationMinutes"));
  return ResponseEntity.ok(Map.of("message","Service created"));
 }
}
